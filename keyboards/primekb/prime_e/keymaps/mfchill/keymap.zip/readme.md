# The default keymap for Prime_E
This is the default keymap for Prime_E.